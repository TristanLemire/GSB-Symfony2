<?php

/* mttlgsbBundle:Default:vAfficherFrais.html.twig */
class __TwigTemplate_fe04f93cc45d53547f7797465926e4ff49f6d12ae3fffc4afbcd73502459ed75 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("mttlgsbBundle:Default:base_Visiteur.html.twig", "mttlgsbBundle:Default:vAfficherFrais.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'titre' => array($this, 'block_titre'),
            'entete' => array($this, 'block_entete'),
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "mttlgsbBundle:Default:base_Visiteur.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a2a7f565798cd768b6b85f268bbf0903f2e88e12fedb9ae1fb27d0f6b3aedeba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a2a7f565798cd768b6b85f268bbf0903f2e88e12fedb9ae1fb27d0f6b3aedeba->enter($__internal_a2a7f565798cd768b6b85f268bbf0903f2e88e12fedb9ae1fb27d0f6b3aedeba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "mttlgsbBundle:Default:vAfficherFrais.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a2a7f565798cd768b6b85f268bbf0903f2e88e12fedb9ae1fb27d0f6b3aedeba->leave($__internal_a2a7f565798cd768b6b85f268bbf0903f2e88e12fedb9ae1fb27d0f6b3aedeba_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_d51ecd1cd11f7362ede21f4e02dff40afacd2997e7588b70f3da99397797c81f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d51ecd1cd11f7362ede21f4e02dff40afacd2997e7588b70f3da99397797c81f->enter($__internal_d51ecd1cd11f7362ede21f4e02dff40afacd2997e7588b70f3da99397797c81f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
    ";
        // line 5
        $this->displayBlock('titre', $context, $blocks);
        
        $__internal_d51ecd1cd11f7362ede21f4e02dff40afacd2997e7588b70f3da99397797c81f->leave($__internal_d51ecd1cd11f7362ede21f4e02dff40afacd2997e7588b70f3da99397797c81f_prof);

    }

    public function block_titre($context, array $blocks = array())
    {
        $__internal_e6908c20618fd37bd4c080a5fc2b41fdd89e3ac64721a282ebe0a5b184de11b7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e6908c20618fd37bd4c080a5fc2b41fdd89e3ac64721a282ebe0a5b184de11b7->enter($__internal_e6908c20618fd37bd4c080a5fc2b41fdd89e3ac64721a282ebe0a5b184de11b7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titre"));

        echo " <title>GSB - Page Afficher fiche de frais</title> ";
        
        $__internal_e6908c20618fd37bd4c080a5fc2b41fdd89e3ac64721a282ebe0a5b184de11b7->leave($__internal_e6908c20618fd37bd4c080a5fc2b41fdd89e3ac64721a282ebe0a5b184de11b7_prof);

    }

    // line 8
    public function block_entete($context, array $blocks = array())
    {
        $__internal_d1ff32e99e9ccb56d3abde20442266cca3013a1349edc6cc0da58d3d9c241742 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d1ff32e99e9ccb56d3abde20442266cca3013a1349edc6cc0da58d3d9c241742->enter($__internal_d1ff32e99e9ccb56d3abde20442266cca3013a1349edc6cc0da58d3d9c241742_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "entete"));

        // line 9
        echo "        ";
        $this->displayParentBlock("entete", $context, $blocks);
        echo "
    ";
        
        $__internal_d1ff32e99e9ccb56d3abde20442266cca3013a1349edc6cc0da58d3d9c241742->leave($__internal_d1ff32e99e9ccb56d3abde20442266cca3013a1349edc6cc0da58d3d9c241742_prof);

    }

    // line 12
    public function block_body($context, array $blocks = array())
    {
        $__internal_208d6220975994f4616cecce09e8a5b8da8212d369bf04af4ec4e01b16436347 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_208d6220975994f4616cecce09e8a5b8da8212d369bf04af4ec4e01b16436347->enter($__internal_208d6220975994f4616cecce09e8a5b8da8212d369bf04af4ec4e01b16436347_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 13
        echo "     <section id=\"team\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-md-12 col-sm-12\">
                        <div class=\"section-title\">
                            <strong>Votre fiche Frais</strong>
                                <hr>
                        </div>
                    </div>
                    <div class=\"col-md-24 col-sm-12 wow fadeIn\" data-wow-delay=\"0.9s\">
                        <div class=\"team-wrapper\">
                           
                           
           
                        </div>
                    </div>
                </div>
            </div>
        </section>
       
     <table class='table table-bordered'>
            <thead >
               <tr>
                   
                    <td class=\"info\">
                       Etat
                    </td>
                    <td class=\"info\">
                        Date de Modification
                    </td>
                    <td class=\"info\">
                        Date de création
                    </td>
                   
               </tr>
            </thead>
            <tbody>
                <tr>
                     <td>
                    ";
        // line 52
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["fiche"]) ? $context["fiche"] : $this->getContext($context, "fiche")), "idEtat", array()), "libelle", array()), "html", null, true);
        echo "
                      </td>
                    <td>
                        
                        ";
        // line 56
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["fiche"]) ? $context["fiche"] : $this->getContext($context, "fiche")), "datemodif", array()), "d-m-Y"), "html", null, true);
        echo "
                    </td>
                   
                    <td>
                        ";
        // line 60
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["fiche"]) ? $context["fiche"] : $this->getContext($context, "fiche")), "mois", array()), "d-m-Y"), "html", null, true);
        echo "
                    </td>
                </tr>
            </tbody>
            </table>
                    <br/>
                    <center>Vos frais forfaitisé :</center>
                    <br/>
            <table class='table  table-bordered'>
                <thead>
                    </tr>
                        <td class=\"info\">
                            Quantité Frais Kilométrique
                        </td>
                        <td class=\"info\">
                          Total Frais Kilométrique
                       </td>
                       <td class=\"info\">
                            Quantité Repas Restaurant 
                        </td>
                       <td class=\"info\">
                          Total Repas Restaurant 
                       </td>
                       <td class=\"info\"> 
                            Quantité Nuitée Hôtel 
                        </td>
                       <td class=\"info\"> 
                          Total Nuitée Hôtel 
                       </td>
                       <td class=\"info\">
                            Quantité Etape
                        </td>
                       <td class=\"info\">
                          Total Etape
                       </td>
                     
                    </tr>
                </thead>
                <tbody>
                     <tr>
                    
                     ";
        // line 101
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["lignes"]) ? $context["lignes"] : $this->getContext($context, "lignes")));
        foreach ($context['_seq'] as $context["_key"] => $context["ligne"]) {
            // line 102
            echo "                          ";
            if (($this->getAttribute($this->getAttribute($context["ligne"], "idfraisforfait", array()), "idfraisforfait", array()) == "KM")) {
                // line 103
                echo "                              ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["types"]) ? $context["types"] : $this->getContext($context, "types")));
                foreach ($context['_seq'] as $context["_key"] => $context["type"]) {
                    // line 104
                    echo "                                  ";
                    if (($this->getAttribute($context["type"], "idfraisforfait", array()) == "KM")) {
                        // line 105
                        echo "                                     <td>
                                         ";
                        // line 106
                        echo twig_escape_filter($this->env, $this->getAttribute($context["ligne"], "quantite", array()), "html", null, true);
                        echo "
                                     </td>
                                     <td>
                                         ";
                        // line 109
                        echo twig_escape_filter($this->env, ($this->getAttribute($context["ligne"], "quantite", array()) * $this->getAttribute($context["type"], "montant", array())), "html", null, true);
                        echo "
                                     </td>
                                  ";
                    }
                    // line 112
                    echo "                            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['type'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 113
                echo "                          ";
            }
            // line 114
            echo "                     ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['ligne'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 115
        echo "                     
                      ";
        // line 116
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["lignes"]) ? $context["lignes"] : $this->getContext($context, "lignes")));
        foreach ($context['_seq'] as $context["_key"] => $context["ligne"]) {
            // line 117
            echo "                          ";
            if (($this->getAttribute($this->getAttribute($context["ligne"], "idfraisforfait", array()), "idfraisforfait", array()) == "REP")) {
                // line 118
                echo "                              ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["types"]) ? $context["types"] : $this->getContext($context, "types")));
                foreach ($context['_seq'] as $context["_key"] => $context["type"]) {
                    // line 119
                    echo "                                  ";
                    if (($this->getAttribute($context["type"], "idfraisforfait", array()) == "REP")) {
                        // line 120
                        echo "                                     <td>
                                         ";
                        // line 121
                        echo twig_escape_filter($this->env, $this->getAttribute($context["ligne"], "quantite", array()), "html", null, true);
                        echo "
                                     </td>
                                     <td>
                                         ";
                        // line 124
                        echo twig_escape_filter($this->env, ($this->getAttribute($context["ligne"], "quantite", array()) * $this->getAttribute($context["type"], "montant", array())), "html", null, true);
                        echo "
                                     </td>
                                  ";
                    }
                    // line 127
                    echo "                            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['type'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 128
                echo "                          ";
            }
            // line 129
            echo "                     ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['ligne'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 130
        echo "                     ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["lignes"]) ? $context["lignes"] : $this->getContext($context, "lignes")));
        foreach ($context['_seq'] as $context["_key"] => $context["ligne"]) {
            // line 131
            echo "                          ";
            if (($this->getAttribute($this->getAttribute($context["ligne"], "idfraisforfait", array()), "idfraisforfait", array()) == "NUI")) {
                // line 132
                echo "                              ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["types"]) ? $context["types"] : $this->getContext($context, "types")));
                foreach ($context['_seq'] as $context["_key"] => $context["type"]) {
                    // line 133
                    echo "                                  ";
                    if (($this->getAttribute($context["type"], "idfraisforfait", array()) == "NUI")) {
                        // line 134
                        echo "                                     <td>
                                         ";
                        // line 135
                        echo twig_escape_filter($this->env, $this->getAttribute($context["ligne"], "quantite", array()), "html", null, true);
                        echo "
                                     </td>
                                     <td>
                                         ";
                        // line 138
                        echo twig_escape_filter($this->env, ($this->getAttribute($context["ligne"], "quantite", array()) * $this->getAttribute($context["type"], "montant", array())), "html", null, true);
                        echo "
                                     </td>
                                  ";
                    }
                    // line 141
                    echo "                            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['type'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 142
                echo "                          ";
            }
            // line 143
            echo "                     ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['ligne'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 144
        echo "                      ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["lignes"]) ? $context["lignes"] : $this->getContext($context, "lignes")));
        foreach ($context['_seq'] as $context["_key"] => $context["ligne"]) {
            // line 145
            echo "                          ";
            if (($this->getAttribute($this->getAttribute($context["ligne"], "idfraisforfait", array()), "idfraisforfait", array()) == "ETP")) {
                // line 146
                echo "                              ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["types"]) ? $context["types"] : $this->getContext($context, "types")));
                foreach ($context['_seq'] as $context["_key"] => $context["type"]) {
                    // line 147
                    echo "                                  ";
                    if (($this->getAttribute($context["type"], "idfraisforfait", array()) == "ETP")) {
                        // line 148
                        echo "                                     <td>
                                         ";
                        // line 149
                        echo twig_escape_filter($this->env, $this->getAttribute($context["ligne"], "quantite", array()), "html", null, true);
                        echo "
                                     </td>
                                     <td>
                                         ";
                        // line 152
                        echo twig_escape_filter($this->env, ($this->getAttribute($context["ligne"], "quantite", array()) * $this->getAttribute($context["type"], "montant", array())), "html", null, true);
                        echo "
                                     </td>
                                  ";
                    }
                    // line 155
                    echo "                            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['type'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 156
                echo "                          ";
            }
            // line 157
            echo "                     ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['ligne'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 158
        echo "                  
                </tr>
                </tbody> 
        </table>
                     <br/>
        <center>Vos frais non forfaitisé :</center>
        <br/>
        <table class='table  table-bordered '>
                <thead>
                    </tr>
                        <td class=\"info\">
                            Libelle
                        </td>
                        <td class=\"info\">
                           Montant 
                       </td>
                       <td class=\"info\">
                           Date de la depense 
                        </td>
                    </tr>
                </thead>
                 <tbody>
                      ";
        // line 180
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["hf"]) ? $context["hf"] : $this->getContext($context, "hf")));
        foreach ($context['_seq'] as $context["_key"] => $context["ligne"]) {
            // line 181
            echo "                     <tr>
                            <td>
                                 ";
            // line 183
            echo twig_escape_filter($this->env, $this->getAttribute($context["ligne"], "libelle", array()), "html", null, true);
            echo "
                            </td>
                            <td>
                                ";
            // line 186
            echo twig_escape_filter($this->env, $this->getAttribute($context["ligne"], "montant", array()), "html", null, true);
            echo "
                            </td>
                            <td>
                                 ";
            // line 189
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["ligne"], "dateDepense", array()), "d-m-Y"), "html", null, true);
            echo "
                            </td>
                     </tr>
                     ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['ligne'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 193
        echo "                 </tbody>
        </table>
   
    ";
        
        $__internal_208d6220975994f4616cecce09e8a5b8da8212d369bf04af4ec4e01b16436347->leave($__internal_208d6220975994f4616cecce09e8a5b8da8212d369bf04af4ec4e01b16436347_prof);

    }

    // line 198
    public function block_footer($context, array $blocks = array())
    {
        $__internal_a2205e32ff4d36b37dbf0e4b727cf43e969dd666a81916d19ea1ba8d819e7461 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a2205e32ff4d36b37dbf0e4b727cf43e969dd666a81916d19ea1ba8d819e7461->enter($__internal_a2205e32ff4d36b37dbf0e4b727cf43e969dd666a81916d19ea1ba8d819e7461_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        // line 199
        echo "        ";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
    ";
        
        $__internal_a2205e32ff4d36b37dbf0e4b727cf43e969dd666a81916d19ea1ba8d819e7461->leave($__internal_a2205e32ff4d36b37dbf0e4b727cf43e969dd666a81916d19ea1ba8d819e7461_prof);

    }

    public function getTemplateName()
    {
        return "mttlgsbBundle:Default:vAfficherFrais.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  443 => 199,  437 => 198,  427 => 193,  417 => 189,  411 => 186,  405 => 183,  401 => 181,  397 => 180,  373 => 158,  367 => 157,  364 => 156,  358 => 155,  352 => 152,  346 => 149,  343 => 148,  340 => 147,  335 => 146,  332 => 145,  327 => 144,  321 => 143,  318 => 142,  312 => 141,  306 => 138,  300 => 135,  297 => 134,  294 => 133,  289 => 132,  286 => 131,  281 => 130,  275 => 129,  272 => 128,  266 => 127,  260 => 124,  254 => 121,  251 => 120,  248 => 119,  243 => 118,  240 => 117,  236 => 116,  233 => 115,  227 => 114,  224 => 113,  218 => 112,  212 => 109,  206 => 106,  203 => 105,  200 => 104,  195 => 103,  192 => 102,  188 => 101,  144 => 60,  137 => 56,  130 => 52,  89 => 13,  83 => 12,  73 => 9,  67 => 8,  49 => 5,  44 => 4,  38 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends \"mttlgsbBundle:Default:base_Visiteur.html.twig\" %}

{% block head %}
    {{ parent() }}
    {% block titre %} <title>GSB - Page Afficher fiche de frais</title> {% endblock %}
{% endblock %}

    {% block entete %}
        {{ parent() }}
    {% endblock %}
    
    {% block body %}
     <section id=\"team\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-md-12 col-sm-12\">
                        <div class=\"section-title\">
                            <strong>Votre fiche Frais</strong>
                                <hr>
                        </div>
                    </div>
                    <div class=\"col-md-24 col-sm-12 wow fadeIn\" data-wow-delay=\"0.9s\">
                        <div class=\"team-wrapper\">
                           
                           
           
                        </div>
                    </div>
                </div>
            </div>
        </section>
       
     <table class='table table-bordered'>
            <thead >
               <tr>
                   
                    <td class=\"info\">
                       Etat
                    </td>
                    <td class=\"info\">
                        Date de Modification
                    </td>
                    <td class=\"info\">
                        Date de création
                    </td>
                   
               </tr>
            </thead>
            <tbody>
                <tr>
                     <td>
                    {{ fiche.idEtat.libelle }}
                      </td>
                    <td>
                        
                        {{ fiche.datemodif|date('d-m-Y') }}
                    </td>
                   
                    <td>
                        {{fiche.mois|date('d-m-Y') }}
                    </td>
                </tr>
            </tbody>
            </table>
                    <br/>
                    <center>Vos frais forfaitisé :</center>
                    <br/>
            <table class='table  table-bordered'>
                <thead>
                    </tr>
                        <td class=\"info\">
                            Quantité Frais Kilométrique
                        </td>
                        <td class=\"info\">
                          Total Frais Kilométrique
                       </td>
                       <td class=\"info\">
                            Quantité Repas Restaurant 
                        </td>
                       <td class=\"info\">
                          Total Repas Restaurant 
                       </td>
                       <td class=\"info\"> 
                            Quantité Nuitée Hôtel 
                        </td>
                       <td class=\"info\"> 
                          Total Nuitée Hôtel 
                       </td>
                       <td class=\"info\">
                            Quantité Etape
                        </td>
                       <td class=\"info\">
                          Total Etape
                       </td>
                     
                    </tr>
                </thead>
                <tbody>
                     <tr>
                    
                     {%for ligne in lignes %}
                          {%if ligne.idfraisforfait.idfraisforfait == 'KM' %}
                              {% for type in types%}
                                  {%if type.idfraisforfait =='KM'%}
                                     <td>
                                         {{ligne.quantite}}
                                     </td>
                                     <td>
                                         {{ligne.quantite * type.montant}}
                                     </td>
                                  {%endif%}
                            {%endfor%}
                          {%endif%}
                     {%endfor%}
                     
                      {%for ligne in lignes %}
                          {%if ligne.idfraisforfait.idfraisforfait == 'REP' %}
                              {% for type in types%}
                                  {%if type.idfraisforfait =='REP'%}
                                     <td>
                                         {{ligne.quantite}}
                                     </td>
                                     <td>
                                         {{ligne.quantite * type.montant}}
                                     </td>
                                  {%endif%}
                            {%endfor%}
                          {%endif%}
                     {%endfor%}
                     {%for ligne in lignes %}
                          {%if ligne.idfraisforfait.idfraisforfait == 'NUI' %}
                              {% for type in types%}
                                  {%if type.idfraisforfait =='NUI'%}
                                     <td>
                                         {{ligne.quantite}}
                                     </td>
                                     <td>
                                         {{ligne.quantite * type.montant}}
                                     </td>
                                  {%endif%}
                            {%endfor%}
                          {%endif%}
                     {%endfor%}
                      {%for ligne in lignes %}
                          {%if ligne.idfraisforfait.idfraisforfait == 'ETP' %}
                              {% for type in types%}
                                  {%if type.idfraisforfait =='ETP'%}
                                     <td>
                                         {{ligne.quantite}}
                                     </td>
                                     <td>
                                         {{ligne.quantite * type.montant}}
                                     </td>
                                  {%endif%}
                            {%endfor%}
                          {%endif%}
                     {%endfor%}
                  
                </tr>
                </tbody> 
        </table>
                     <br/>
        <center>Vos frais non forfaitisé :</center>
        <br/>
        <table class='table  table-bordered '>
                <thead>
                    </tr>
                        <td class=\"info\">
                            Libelle
                        </td>
                        <td class=\"info\">
                           Montant 
                       </td>
                       <td class=\"info\">
                           Date de la depense 
                        </td>
                    </tr>
                </thead>
                 <tbody>
                      {%for ligne in hf%}
                     <tr>
                            <td>
                                 {{ligne.libelle}}
                            </td>
                            <td>
                                {{ligne.montant}}
                            </td>
                            <td>
                                 {{ligne.dateDepense |date('d-m-Y') }}
                            </td>
                     </tr>
                     {%endfor%}
                 </tbody>
        </table>
   
    {% endblock %}
    
    {% block footer %}
        {{ parent() }}
    {% endblock %}{# empty Twig template #}";
    }
}
